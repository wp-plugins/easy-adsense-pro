<?php echo '<b><font color="red">Pro Features: </font>' ; printf(__('Support %s by Donating Ad Space', 'easy-adsenser'), 'Easy AdSense') ; ?></b><br />
<?php _e('Percentage of ad slots to share [Default: 5%]:', 'easy-adsenser') ; ?> <input style="width:30px;text-align:center;" id="ezMC" name="ezMC" value="<?php echo(stripslashes(htmlspecialchars($ezAdOptions['mc'])));?>" />%<br />
<label for="ezAllowPopunder" title="Share your thoughts and comments on this option using the support links below.">
<input type="checkbox" id="ezAllowPopunder" name="ezAllowPopunder"  <?php if ($ezAdOptions['allow_popunder'] == 'Yes') { echo('checked="checked"'); }?> /> <?php _e('Allow popunders once a day to support the plugin development.', 'easy-adsenser') ; ?></label>
<br style="line-height: 12px;" />

<b><?php _e('Link-backs to', 'easy-adsenser') ; ?> <a href="http://www.Thulasidas.com" target="_blank">Unreal Blog</a></b>
<?php _e('(Consider showing at least one link.)', 'easy-adsenser') ; ?><br />
<label for="ezAdSenseLinkMax99">
<input type="radio" id="ezAdSenseLinkMax99" name="ezAdSenseLinkMax" value="99" <?php if ($ezAdOptions['max_link'] == 99) { echo('checked="checked"'); }?> /> <?php _e('Show a link under every ad block.', 'easy-adsenser') ; ?></label><br />
<label for="ezAdSenseLinkMax1">
<input type="radio" id="ezAdSenseLinkMax1" name="ezAdSenseLinkMax" value="1" <?php if ($ezAdOptions['max_link'] == 1) { echo('checked="checked"'); }?> /> <?php _e('Show the link only under the first ad block.', 'easy-adsenser') ; ?></label><br />
<label for="ezAdSenseLinkMax-1">
<input type="radio" id="ezAdSenseLinkMax-1" name="ezAdSenseLinkMax" value="-1" <?php if ($ezAdOptions['max_link'] == -1) { echo('checked="checked"'); }?> /> <?php _e('Show the link at the bottom of your blog page.', 'easy-adsenser') ; ?></label><br />
<label for="ezAdSenseLinkMax0">
<input type="radio" id="ezAdSenseLinkMax0" name="ezAdSenseLinkMax" value="0" <?php if ($ezAdOptions['max_link'] == 0) { echo('checked="checked"'); }?> /> <?php _e('Show no links to my blog anywhere (Are you sure?!)', 'easy-adsenser') ; echo '</label>' ?>

